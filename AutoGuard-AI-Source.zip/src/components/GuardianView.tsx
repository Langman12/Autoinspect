import { useEffect, useRef, useState } from 'react'
import { geminiService } from '../services/geminiService'
import { weatherService, WEATHER_PRESETS, type WeatherPreset } from '../services/weatherService'
import type { GuardianMission, WeatherHazard, WeatherReport } from '../types'

interface SimulatedHazard {
  id: string
  type: 'POTHOLE' | 'SPEED_TRAP' | 'STANDING_WATER' | 'DEBRIS' | 'BLACK_ICE' | 'HYDROPLANING' | 'CROSSWINDS' | 'DENSE_FOG' | 'THUNDERSTORM'
  distanceMeters: number
  description: string
  severity: 'CRITICAL' | 'WARNING' | 'INFO'
  source?: 'RADAR' | 'WEATHER' | 'USER'
}

export function GuardianView() {
  const [isActive, setIsActive] = useState(false)
  const [destination, setDestination] = useState('Dallas, TX')
  const [vehicleProfile, setVehicleProfile] = useState('2024 Passenger Sedan')
  const [threatLevel, setThreatLevel] = useState<GuardianMission['threatLevel']>('high')
  const [routePriority, setRoutePriority] = useState<GuardianMission['routePriority']>('fastest')
  const [weatherAvoidance, setWeatherAvoidance] = useState<boolean>(true)
  const [position, setPosition] = useState<GeolocationPosition | null>(null)
  const [transcript, setTranscript] = useState<string[]>([])
  const [voiceCoPilotEnabled, setVoiceCoPilotEnabled] = useState(true)
  const [currentSpeedKmh, setCurrentSpeedKmh] = useState<number>(0)
  const [speedLimitKmh, setSpeedLimitKmh] = useState<number>(60)
  const [activePreset, setActivePreset] = useState<string>('current')

  // Live Weather Telemetry State
  const [weatherReport, setWeatherReport] = useState<WeatherReport | null>(null)
  const [isWeatherLoading, setIsWeatherLoading] = useState<boolean>(false)
  const [weatherError, setWeatherError] = useState<string | null>(null)

  const [hazards, setHazards] = useState<SimulatedHazard[]>([
    { id: 'h1', type: 'POTHOLE', distanceMeters: 450, description: 'Severe pothole in right lane', severity: 'WARNING', source: 'RADAR' },
    { id: 'h2', type: 'SPEED_TRAP', distanceMeters: 800, description: 'Mobile speed enforcement unit ahead', severity: 'INFO', source: 'RADAR' },
  ])

  const watchIdRef = useRef<number | null>(null)
  const guardianSessionRef = useRef<any>(null)
  const audioContextRef = useRef<AudioContext | null>(null)

  // Spoken voice announcement
  const speakVoice = (text: string) => {
    if (!voiceCoPilotEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) return
    try {
      window.speechSynthesis?.cancel()
      const utterance = new SpeechSynthesisUtterance(text.replace(/[*_#]/g, ''))
      utterance.rate = 1.05
      utterance.pitch = 1.0
      window.speechSynthesis.speak(utterance)
    } catch (e) {
      console.warn('Speech synthesis error:', e)
    }
  }

  const playAudio = async (b64: string) => {
    try {
      const ctx = audioContextRef.current || new AudioContext()
      audioContextRef.current = ctx
      const raw = atob(b64)
      const buf = new Uint8Array(raw.length)
      for (let i = 0; i < raw.length; i++) buf[i] = raw.charCodeAt(i)
      const audioBuf = await ctx.decodeAudioData(buf.buffer.slice(0))
      const src = ctx.createBufferSource()
      src.buffer = audioBuf
      src.connect(ctx.destination)
      src.start()
    } catch (err) {
      console.warn('Audio playback skipped', err)
    }
  }

  // Load weather for a given preset or GPS
  const loadWeatherForLocation = async (preset: WeatherPreset) => {
    setActivePreset(preset.id)
    setIsWeatherLoading(true)
    setWeatherError(null)

    try {
      let report: WeatherReport | null = null

      if (preset.id === 'current') {
        if (navigator.geolocation) {
          report = await new Promise<WeatherReport | null>((resolve) => {
            navigator.geolocation.getCurrentPosition(
              async (pos) => {
                setPosition(pos)
                const res = await weatherService.fetchWeatherByCoordinates(
                  pos.coords.latitude,
                  pos.coords.longitude,
                  'Current Device Location'
                )
                resolve(res)
              },
              async () => {
                // Default fallback if geolocation denied
                const res = await weatherService.fetchWeatherByCoordinates(51.5074, -0.1278, 'London (GPS Default)')
                resolve(res)
              },
              { timeout: 4000 }
            )
          })
        } else {
          report = await weatherService.fetchWeatherByCoordinates(51.5074, -0.1278, 'London (Default)')
        }
      } else {
        report = await weatherService.fetchWeatherByCoordinates(
          preset.latitude,
          preset.longitude,
          preset.locationName
        )
      }

      if (report) {
        setWeatherReport(report)
        applyWeatherToRadar(report)
      }
    } catch (err: any) {
      console.error('[Guardian] Weather fetch failed:', err)
      setWeatherError(err.message || 'Unable to retrieve location weather')
    } finally {
      setIsWeatherLoading(false)
    }
  }

  // Apply detected weather hazards to GPS radar and adjust safe speed
  const applyWeatherToRadar = (report: WeatherReport) => {
    if (report.safeSpeedCapKmh && report.safeSpeedCapKmh < speedLimitKmh) {
      setSpeedLimitKmh(report.safeSpeedCapKmh)
    }

    if (report.hazards.length > 0) {
      const weatherHazards: SimulatedHazard[] = report.hazards.map((wh, idx) => ({
        id: `wh-${wh.id}-${idx}`,
        type: wh.type as any,
        distanceMeters: (idx + 1) * 320,
        description: `${wh.title}: ${wh.description}`,
        severity: wh.severity,
        source: 'WEATHER',
      }))

      setHazards((prev) => {
        const nonWeather = prev.filter((h) => h.source !== 'WEATHER')
        return [...weatherHazards, ...nonWeather].slice(0, 7)
      })

      // If active, speak top hazard warning
      if (isActive) {
        const top = report.hazards[0]
        const announcement = `Tactical Weather Alert: ${top.title}. ${top.recommendedAction}`
        setTranscript((prev) => [...prev, `[WEATHER SHIELD] ${announcement}`])
        speakVoice(announcement)
      }
    }
  }

  // Auto-load initial weather on mount
  useEffect(() => {
    loadWeatherForLocation(WEATHER_PRESETS[0])
  }, [])

  const startLocationTracking = () => {
    if (!navigator.geolocation) {
      console.warn('GPS not available on this browser.')
      return
    }
    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        setPosition(pos)
        const speed = Math.round((pos.coords.speed || 0) * 3.6)
        setCurrentSpeedKmh(speed)

        if (guardianSessionRef.current) {
          const weatherSummary = weatherReport
            ? `, Weather: ${weatherReport.conditionText} ${weatherReport.temperatureC}°C, Grip: ${weatherReport.roadGripIndex}%`
            : ''
          const locationUpdate = `LOCATION UPDATE: Lat ${pos.coords.latitude.toFixed(5)}, Lon ${pos.coords.longitude.toFixed(5)}, Speed ${speed} km/h${weatherSummary}`
          guardianSessionRef.current.sendMessage?.({ text: locationUpdate })
        }
      },
      (err) => console.error('GPS error:', err),
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 5000 }
    )
  }

  const toggleGuardian = async () => {
    if (isActive) {
      guardianSessionRef.current?.close?.()
      guardianSessionRef.current = null
      if (watchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current)
        watchIdRef.current = null
      }
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {})
        audioContextRef.current = null
      }
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel()
      }
      setIsActive(false)
      setTranscript((prev) => [...prev, 'GUARDIAN: Mission terminated. Safe travels.'])
      return
    }

    if (!destination.trim()) {
      alert('Please enter a target destination before activating Guardian.')
      return
    }

    // Attempt to refresh weather for the mission
    let currentW = weatherReport
    if (destination.trim() && activePreset === 'current') {
      try {
        const destWeather = await weatherService.fetchWeatherByLocationName(destination)
        if (destWeather) {
          currentW = destWeather
          setWeatherReport(destWeather)
          applyWeatherToRadar(destWeather)
        }
      } catch (e) {
        console.warn('Destination weather lookup skipped:', e)
      }
    }

    const mission: GuardianMission = {
      destination,
      vehicleProfile,
      threatLevel,
      routePriority: weatherAvoidance && currentW?.roadHazardLevel === 'SEVERE_DANGER' ? 'scenic' : routePriority,
      weatherAvoidance,
      currentWeather: currentW,
    }

    setIsActive(true)
    startLocationTracking()

    const weatherVoiceText = currentW
      ? ` Weather Radar: ${currentW.conditionText} at ${currentW.temperatureC} degrees Celsius. Road Grip Index: ${currentW.roadGripIndex} percent. ${currentW.tacticalAdvisory}`
      : ''

    const initialMsg = `GUARDIAN: Tactical 4-Layer Shield active. Destination locked: ${destination}. Monitoring all surface hazards, traffic flow, and radar.${weatherVoiceText}`
    setTranscript((prev) => [...prev, initialMsg])
    speakVoice(initialMsg)

    try {
      const session = await geminiService.connectGuardianLive(mission, {
        onopen: () => {
          session.sendMessage?.({
            text: `Mission initiated. Destination: ${mission.destination}. Vehicle: ${mission.vehicleProfile}. Threat Level: ${mission.threatLevel}. Weather Shield: ${weatherAvoidance ? 'ACTIVE' : 'STANDBY'}.`,
          })
        },
        onmessage: (msg: any) => {
          const text = msg.serverContent?.modelTurn?.parts?.find((p: any) => p.text)?.text
          if (text) {
            setTranscript((prev) => [...prev.slice(-25), 'GUARDIAN: ' + text])
            speakVoice(text)
          }
          const audio = msg.serverContent?.modelTurn?.parts?.find((p: any) =>
            p.inlineData?.mimeType?.startsWith('audio')
          )
          if (audio) playAudio(audio.inlineData.data)
        },
        onerror: (err: any) => {
          setTranscript((prev) => [...prev, 'ERROR: ' + err.message])
        },
        onclose: () => {
          setIsActive(false)
        },
      })
      guardianSessionRef.current = session
    } catch (err: any) {
      console.warn('Guardian Live session offline, using local Tactical Shield co-pilot:', err)
    }
  }

  const triggerSimulatedHazard = (type: SimulatedHazard['type']) => {
    const hazardNames = {
      POTHOLE: 'Deep pothole detected 300m ahead in lane 2',
      SPEED_TRAP: 'Speed enforcement camera 400m ahead. Limit 60 km/h',
      STANDING_WATER: 'Flash pooling / standing water risk on roadway',
      DEBRIS: 'Tire tread debris reported in center lane',
      BLACK_ICE: 'Sub-zero road surface temperature — black ice caution',
      HYDROPLANING: 'Severe hydroplaning threshold exceeded. Reduce speed by 30 km/h',
      CROSSWINDS: 'Sudden 65 km/h bridge crosswind sheer detected',
      DENSE_FOG: 'Dense fog bank ahead — visibility dropping below 300m',
      THUNDERSTORM: 'Severe convective storm cell crossing navigation vector',
    }
    const newHazard: SimulatedHazard = {
      id: 'h-' + Date.now(),
      type,
      distanceMeters: 350,
      description: hazardNames[type] || 'Unidentified tactical road anomaly',
      severity: ['BLACK_ICE', 'POTHOLE', 'HYDROPLANING', 'THUNDERSTORM'].includes(type) ? 'CRITICAL' : 'WARNING',
      source: 'USER',
    }
    setHazards((prev) => [newHazard, ...prev.slice(0, 6)])
    const alertText = `Tactical Alert: ${newHazard.description}. Reduce speed.`
    setTranscript((prev) => [...prev, `[TACTICAL SHIELD] ${alertText}`])
    speakVoice(alertText)
  }

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current)
        watchIdRef.current = null
      }
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {})
        audioContextRef.current = null
      }
      guardianSessionRef.current?.close?.()
      guardianSessionRef.current = null
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.cancel()
      }
    }
  }, [])

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <p className="text-[10px] uppercase tracking-[0.3em] text-cyan-400 font-black">
            Global Guardian GPS Co-Pilot
          </p>
          <h2 className="text-2xl font-black text-white">Tactical Weather & Live Shield</h2>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Weather Avoidance Toggle */}
          <button
            onClick={() => setWeatherAvoidance(!weatherAvoidance)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase border transition-all flex items-center gap-1.5 ${
              weatherAvoidance
                ? 'bg-emerald-950 border-emerald-600 text-emerald-300 shadow-sm shadow-emerald-900/40'
                : 'bg-slate-900 border-slate-700 text-slate-500'
            }`}
          >
            <span>🛡️</span>
            <span>{weatherAvoidance ? 'Weather Avoidance ON' : 'Weather Avoidance OFF'}</span>
          </button>

          {/* Voice Co-Pilot Toggle */}
          <button
            onClick={() => setVoiceCoPilotEnabled(!voiceCoPilotEnabled)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase border transition-all ${
              voiceCoPilotEnabled
                ? 'bg-cyan-950 border-cyan-600 text-cyan-300'
                : 'bg-slate-900 border-slate-700 text-slate-500'
            }`}
          >
            {voiceCoPilotEnabled ? '🔊 Voice ON' : '🔇 Muted'}
          </button>
        </div>
      </div>

      {/* Weather Scenario / Location Quick-Presets */}
      <div className="space-y-2">
        <div className="flex justify-between items-center text-xs">
          <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">
            Live GPS Weather Source & Test Scenarios
          </span>
          {isWeatherLoading && (
            <span className="text-[10px] text-cyan-400 animate-pulse font-mono flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              Fetching Live Weather...
            </span>
          )}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {WEATHER_PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => loadWeatherForLocation(p)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap border transition-all ${
                activePreset === p.id
                  ? 'bg-cyan-600 text-white border-cyan-400 shadow-md shadow-cyan-900/30'
                  : 'bg-slate-900/90 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Mission Configuration */}
      <div className="grid gap-3 md:grid-cols-4 bg-slate-900/80 border border-slate-800 p-4 rounded-3xl">
        <input
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          placeholder="Destination address or city"
          className="px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white text-sm outline-none focus:border-cyan-500 font-sans"
        />
        <input
          value={vehicleProfile}
          onChange={(e) => setVehicleProfile(e.target.value)}
          placeholder="Vehicle profile (e.g. 2024 Sedan)"
          className="px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white text-sm outline-none focus:border-cyan-500 font-sans"
        />
        <select
          value={threatLevel}
          onChange={(e) => setThreatLevel(e.target.value as GuardianMission['threatLevel'])}
          className="px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white text-sm outline-none font-sans"
        >
          <option value="low">Threat Profile: Standard</option>
          <option value="medium">Threat Profile: Elevated</option>
          <option value="high">Threat Profile: Maximum Tactical</option>
        </select>
        <select
          value={routePriority}
          onChange={(e) => setRoutePriority(e.target.value as GuardianMission['routePriority'])}
          className="px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white text-sm outline-none font-sans"
        >
          <option value="fastest">Route: Fastest + Rat Run</option>
          <option value="avoid-tolls">Route: Avoid Tolls</option>
          <option value="scenic">Route: Smooth Surface Only</option>
        </select>
      </div>

      {/* Live Tactical Weather Radar & Road Surface Grip HUD Card */}
      {weatherReport && (
        <div
          className={`rounded-3xl border p-5 md:p-6 space-y-4 shadow-xl transition-all ${
            weatherReport.roadHazardLevel === 'SEVERE_DANGER'
              ? 'bg-rose-950/30 border-rose-800/80 shadow-rose-950/20'
              : weatherReport.roadHazardLevel === 'HAZARDOUS'
              ? 'bg-amber-950/30 border-amber-800/80 shadow-amber-950/20'
              : 'bg-slate-900/90 border-slate-800'
          }`}
        >
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-3">
              <span className="text-3xl p-2 rounded-2xl bg-slate-950 border border-slate-800">
                {weatherReport.conditionIcon}
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-black text-white">{weatherReport.locationName}</h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-950 text-cyan-300 border border-slate-800">
                    Live Open-Meteo
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {weatherReport.conditionText} · {weatherReport.temperatureC}°C (Feels like {weatherReport.apparentTemperatureC}°C)
                </p>
              </div>
            </div>

            {/* Road Grip Index & Hazard Level Badge */}
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-[10px] uppercase font-bold text-slate-400">Road Grip Index</p>
                <p
                  className={`text-xl font-black font-mono ${
                    weatherReport.roadGripIndex > 75
                      ? 'text-emerald-400'
                      : weatherReport.roadGripIndex > 50
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {weatherReport.roadGripIndex}%
                </p>
              </div>
              <span
                className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider border ${
                  weatherReport.roadHazardLevel === 'SEVERE_DANGER'
                    ? 'bg-rose-950 text-rose-300 border-rose-700 animate-pulse'
                    : weatherReport.roadHazardLevel === 'HAZARDOUS'
                    ? 'bg-amber-950 text-amber-300 border-amber-700'
                    : weatherReport.roadHazardLevel === 'CAUTION'
                    ? 'bg-yellow-950 text-yellow-300 border-yellow-700'
                    : 'bg-emerald-950 text-emerald-300 border-emerald-700'
                }`}
              >
                {weatherReport.roadHazardLevel.replace('_', ' ')}
              </span>
            </div>
          </div>

          {/* Meteorological Metrics Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">💨 Wind / Gusts</p>
              <p className="text-white font-black font-mono mt-1">
                {weatherReport.windSpeedKmh} <span className="text-[10px] text-slate-400">km/h</span>
              </p>
              <p className="text-[10px] text-slate-500 font-mono">Gusts to {weatherReport.windGustsKmh} km/h</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">🌧️ Precipitation</p>
              <p className="text-cyan-400 font-black font-mono mt-1">
                {weatherReport.precipitationMm} <span className="text-[10px] text-slate-400">mm/h</span>
              </p>
              <p className="text-[10px] text-slate-500 font-mono">{weatherReport.precipitationProbability}% prob</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">👁️ Visibility</p>
              <p className="text-white font-black font-mono mt-1">
                {(weatherReport.visibilityMeters / 1000).toFixed(1)} <span className="text-[10px] text-slate-400">km</span>
              </p>
              <p className="text-[10px] text-slate-500 font-mono">
                {weatherReport.visibilityMeters < 1000 ? '⚠️ Low Sightline' : 'Clear Sightline'}
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">🛑 Safe Speed Cap</p>
              <p className="text-amber-400 font-black font-mono mt-1">
                {weatherReport.safeSpeedCapKmh} <span className="text-[10px] text-slate-400">km/h</span>
              </p>
              <p className="text-[10px] text-slate-500">Hydroplane limit</p>
            </div>
          </div>

          {/* Tactical Weather Warning Alert Box */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xl mt-0.5">⚠️</span>
            <div className="text-xs space-y-0.5">
              <strong className="text-white font-black uppercase tracking-wider block">
                Tactical Weather Advisory
              </strong>
              <p className="text-slate-300 leading-relaxed font-sans">{weatherReport.tacticalAdvisory}</p>
            </div>
          </div>
        </div>
      )}

      {/* Tactical HUD & Telemetry */}
      <div className="grid md:grid-cols-3 gap-4">
        {/* Speedometer & Limits */}
        <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-5 flex flex-col justify-between">
          <div className="flex justify-between items-center text-xs text-slate-400 font-mono">
            <span>LIVE TELEMETRY</span>
            <span className={currentSpeedKmh > speedLimitKmh ? 'text-red-400 font-bold animate-pulse' : 'text-emerald-400'}>
              {currentSpeedKmh > speedLimitKmh ? '⚠️ OVERSPEED' : 'SPEED OK'}
            </span>
          </div>
          <div className="text-center py-4">
            <span className="text-6xl font-black text-white font-mono">{currentSpeedKmh}</span>
            <span className="text-sm font-bold text-slate-400 ml-1">KM/H</span>
            <div className="mt-2 text-xs font-mono text-cyan-400">
              Target Speed Cap: <strong className="text-white">{speedLimitKmh} km/h</strong>
            </div>
          </div>
          <div className="text-xs text-slate-500 text-center font-mono">
            {position
              ? `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`
              : 'GPS Locked · Radar Active'}
          </div>
        </div>

        {/* 4-Layer Shield Status */}
        <div className="md:col-span-2 rounded-3xl border border-slate-800 bg-slate-900/90 p-5 space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-xs font-black uppercase tracking-wider text-cyan-400">
              4-Layer Live Shield Status
            </span>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800">
              {isActive ? 'SHIELD ONLINE' : 'STANDBY'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">1. Traffic & Flow</p>
              <p className="text-white font-black mt-1">Rat Run Ready</p>
              <p className="text-[10px] text-slate-500">Auto-detour on gridlock</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">2. Surface Hazards</p>
              <p className="text-amber-400 font-black mt-1">500m Radar</p>
              <p className="text-[10px] text-slate-500">Pothole / Ice scanner</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">3. Speed Shield</p>
              <p className="text-emerald-400 font-black mt-1">400m Alert</p>
              <p className="text-[10px] text-slate-500">Radar enforcement</p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <p className="text-slate-400 text-[10px] uppercase font-bold">4. Weather Radar</p>
              <p className={`font-black mt-1 ${weatherReport?.roadHazardLevel === 'SEVERE_DANGER' ? 'text-rose-400' : 'text-cyan-400'}`}>
                {weatherReport ? weatherReport.conditionText.slice(0, 14) : 'Active'}
              </p>
              <p className="text-[10px] text-slate-500">Grip: {weatherReport?.roadGripIndex || 95}%</p>
            </div>
          </div>

          {/* Quick Simulated Hazard Triggers */}
          <div className="pt-2 border-t border-slate-800/80 flex flex-wrap gap-2 items-center">
            <span className="text-[10px] uppercase text-slate-400 font-bold">Inject Hazard:</span>
            <button
              onClick={() => triggerSimulatedHazard('HYDROPLANING')}
              className="px-2.5 py-1 rounded-lg bg-blue-950 hover:bg-blue-900 border border-blue-800 text-blue-200 text-xs font-bold"
            >
              🌊 Hydroplane Risk
            </button>
            <button
              onClick={() => triggerSimulatedHazard('BLACK_ICE')}
              className="px-2.5 py-1 rounded-lg bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-200 text-xs font-bold"
            >
              🧊 Black Ice
            </button>
            <button
              onClick={() => triggerSimulatedHazard('CROSSWINDS')}
              className="px-2.5 py-1 rounded-lg bg-indigo-950 hover:bg-indigo-900 border border-indigo-800 text-indigo-200 text-xs font-bold"
            >
              🌪️ Gale Winds
            </button>
            <button
              onClick={() => triggerSimulatedHazard('POTHOLE')}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold"
            >
              ⚠️ Pothole
            </button>
          </div>
        </div>
      </div>

      {/* Main Action Activation Button */}
      <button
        onClick={toggleGuardian}
        className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-wider transition-all shadow-xl ${
          isActive
            ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-950/40'
            : 'bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 hover:opacity-90 text-white shadow-cyan-950/40'
        }`}
      >
        {isActive ? '⏹ Abort Guardian Mission' : '🛡️ Activate Tactical Global Guardian & Weather Shield'}
      </button>

      {/* Active Hazards Feed & Voice Transcript */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Nearby Hazards Radar Feed */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3">
          <div className="flex justify-between items-center">
            <p className="text-xs font-black uppercase tracking-wider text-slate-400">
              Active Radar & Weather Hazards ({hazards.length})
            </p>
            <span className="text-xs font-mono text-cyan-400">Radar Scanning</span>
          </div>
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {hazards.map((h) => (
              <div
                key={h.id}
                className={`p-3 rounded-2xl border text-xs flex items-center justify-between gap-3 ${
                  h.severity === 'CRITICAL'
                    ? 'bg-red-950/40 border-red-800 text-red-200'
                    : 'bg-amber-950/40 border-amber-800 text-amber-200'
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold">{h.description}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                    <span>Type: {h.type}</span>
                    {h.source === 'WEATHER' && (
                      <span className="px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                        WEATHER RADAR
                      </span>
                    )}
                  </div>
                </div>
                <span className="font-mono font-bold text-sm whitespace-nowrap">{h.distanceMeters}m</span>
              </div>
            ))}
          </div>
        </div>

        {/* Live Audio / Voice Transcript */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-3">
              <p className="text-xs font-black uppercase tracking-wider text-slate-400">
                Co-Pilot Voice & Action Log
              </p>
              <span className="text-[10px] text-slate-500 font-mono">Live Radio</span>
            </div>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {transcript.length === 0 && (
                <p className="text-slate-500 text-xs italic">
                  Guardian tactical radio is silent. Enter destination and activate to begin.
                </p>
              )}
              {transcript.map((line, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-200">
                  {line}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
