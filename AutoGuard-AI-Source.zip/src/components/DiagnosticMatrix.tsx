import { useState } from 'react'

interface DiagnosticItem {
  id: string
  category: 'Acoustic' | 'Exhaust Smoke' | 'Undercarriage & Body' | 'EV & Hybrid' | 'Safety & ADAS'
  symptom: string
  rootCause: string
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'
  action: string
  frequencyOrSpecs?: string
}

const DIAGNOSTIC_DATABASE: DiagnosticItem[] = [
  // Acoustic
  {
    id: 'ac-1',
    category: 'Acoustic',
    symptom: 'Deep, hollow metallic knocking at idle (600-800 RPM)',
    rootCause: 'Connecting rod bearing spun or severe piston slap',
    severity: 'CRITICAL',
    action: '🔴 FAIL ENGINE — TOW TRUCK ONLY. Do not rev. Engine rebuild required.',
    frequencyOrSpecs: '200 Hz - 800 Hz',
  },
  {
    id: 'ac-2',
    category: 'Acoustic',
    symptom: 'High-frequency rhythmic ticking from cylinder head',
    rootCause: 'Hydraulic valve lifter failure, loose rocker arm, or exhaust manifold leak',
    severity: 'MEDIUM',
    action: '🟡 Inspect valvetrain clearance and exhaust manifold gasket studs.',
    frequencyOrSpecs: '800 Hz - 2.5 kHz',
  },
  {
    id: 'ac-3',
    category: 'Acoustic',
    symptom: 'Loud grinding noise when brake pedal is applied',
    rootCause: 'Brake pads worn down to steel backing plate; metal-to-metal rotor gouging',
    severity: 'CRITICAL',
    action: '🔴 IMMEDIATE BRAKE OVERHAUL. Replace pads & rotors. Do not drive on highway.',
    frequencyOrSpecs: '1.2 kHz - 4 kHz',
  },
  {
    id: 'ac-4',
    category: 'Acoustic',
    symptom: 'Continuous humming/whining drone proportional to road speed',
    rootCause: 'Wheel bearing race pitting or differential pinion bearing wear',
    severity: 'HIGH',
    action: '🟡 Jack vehicle up, check for 12/6 o\'clock hub play. Replace hub assembly.',
    frequencyOrSpecs: '2 kHz - 6 kHz',
  },
  {
    id: 'ac-5',
    category: 'Acoustic',
    symptom: 'Rhythmic clicking/popping during tight low-speed turns',
    rootCause: 'Constant Velocity (CV) joint boot torn and ball cage degraded',
    severity: 'HIGH',
    action: '🟡 Replace complete CV half-shaft axle assembly.',
    frequencyOrSpecs: '500 Hz - 1.5 kHz',
  },

  // Exhaust Smoke
  {
    id: 'sm-1',
    category: 'Exhaust Smoke',
    symptom: 'Blue smoke from exhaust on startup and acceleration',
    rootCause: 'Burning engine oil past worn piston rings, valve stem seals, or blown turbo seal',
    severity: 'CRITICAL',
    action: '🔴 FAIL ENGINE / TURBO — High oil consumption hazard. Check spark plugs for fouling.',
    frequencyOrSpecs: 'Exhaust chemical marker',
  },
  {
    id: 'sm-2',
    category: 'Exhaust Smoke',
    symptom: 'Thick white smoke with sweet odor that lingers in air',
    rootCause: 'Coolant combustion from blown cylinder head gasket or cracked engine block',
    severity: 'CRITICAL',
    action: '🔴 CRITICAL ENGINE FAILURE — Risk of hydraulic lock and immediate overheating.',
    frequencyOrSpecs: 'Ethylene glycol vaporization',
  },
  {
    id: 'sm-3',
    category: 'Exhaust Smoke',
    symptom: 'Heavy black smoke under moderate throttle (Diesel / Petrol)',
    rootCause: 'Incomplete combustion: clogged air filter, leaking injector, failed MAF or DPF failure',
    severity: 'MEDIUM',
    action: '🟡 Clean air intake, test injector spray balance and DPF differential pressure.',
    frequencyOrSpecs: 'Excess soot particulate',
  },

  // Undercarriage & Body
  {
    id: 'uc-1',
    category: 'Undercarriage & Body',
    symptom: 'Parallel linear clamp marks on unibody frame pinch welds',
    rootCause: 'Vehicle was previously mounted on a frame-pulling bench after a severe collision',
    severity: 'CRITICAL',
    action: '🔴 PRIOR CRASH CONCEALMENT — Laser frame alignment verification mandatory.',
    frequencyOrSpecs: 'Frame tolerance > 1.0mm',
  },
  {
    id: 'uc-2',
    category: 'Undercarriage & Body',
    symptom: 'Fresh localized spray undercoating covering frame rails only',
    rootCause: 'Attempt to conceal structural rust rot or crude stitch weld repairs',
    severity: 'CRITICAL',
    action: '🔴 SCRAPE & PROBE TEST — Check with ultrasound thickness gauge and pick hammer.',
    frequencyOrSpecs: 'Coating variation > 500 microns',
  },
  {
    id: 'uc-3',
    category: 'Undercarriage & Body',
    symptom: 'Orange peel waviness and uneven panel gap (> 2mm delta)',
    rootCause: 'Non-OEM aftermarket replacement panel with heavy polyester Bondo filler',
    severity: 'HIGH',
    action: '🟡 Measure paint depth (Normal OEM: 90-140 µm; Bondo: > 400 µm).',
    frequencyOrSpecs: 'Paint meter > 350 µm',
  },

  // EV & Hybrid
  {
    id: 'ev-1',
    category: 'EV & Hybrid',
    symptom: 'High-pitch electrical inverter screeching under regenerative braking',
    rootCause: 'IGBT gate driver degradation or motor phase stator insulation breakdown',
    severity: 'CRITICAL',
    action: '🔴 HV INVERTER FAULT — HV isolation test required before customer handover.',
    frequencyOrSpecs: '8 kHz - 16 kHz',
  },
  {
    id: 'ev-2',
    category: 'EV & Hybrid',
    symptom: 'Underside battery pack casing scrape or enclosure puncture',
    rootCause: 'Road debris impact causing structural deformation to lithium pouch/cylindrical cells',
    severity: 'CRITICAL',
    action: '🔴 THERMAL RUNAWAY RISK — Isolate vehicle in designated fire-safe zone immediately.',
    frequencyOrSpecs: 'Enclosure depth > 3mm',
  },
  {
    id: 'ev-3',
    category: 'EV & Hybrid',
    symptom: 'Suspension creak and groan during low-speed EV roll',
    rootCause: 'Heavy EV curb weight accelerating lower control arm bushing and ball joint tearing',
    severity: 'MEDIUM',
    action: '🟡 Replace heavy-duty polyurethane or spherical suspension bushings.',
    frequencyOrSpecs: '100 Hz - 400 Hz',
  },

  // Safety & ADAS
  {
    id: 'sf-1',
    category: 'Safety & ADAS',
    symptom: 'Windshield replaced without camera radar recalibration target sweep',
    rootCause: 'Forward collision warning (FCW) & Lane Keep Assist (LKA) cameras misaligned',
    severity: 'CRITICAL',
    action: '🔴 ADAS RECALIBRATION MANDATORY before test drive to prevent false braking.',
    frequencyOrSpecs: 'Optical target sweep',
  },
  {
    id: 'sf-2',
    category: 'Safety & ADAS',
    symptom: 'White powder residue around steering wheel or dashboard seams',
    rootCause: 'Sodium azide deployment residue from prior airbag deployment; dummy cover installed',
    severity: 'CRITICAL',
    action: '🔴 AIRBAG FRAUD DETECTED — TOW TRUCK ONLY. Zero crash protection.',
    frequencyOrSpecs: 'Sodium azide chemical trace',
  },
]

export function DiagnosticMatrix() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All')
  const [searchTerm, setSearchTerm] = useState('')
  const [activeItem, setActiveItem] = useState<DiagnosticItem | null>(null)

  const categories = ['All', 'Acoustic', 'Exhaust Smoke', 'Undercarriage & Body', 'EV & Hybrid', 'Safety & ADAS']

  const filteredItems = DIAGNOSTIC_DATABASE.filter((item) => {
    const matchesCat = selectedCategory === 'All' || item.category === selectedCategory
    const matchesSearch =
      item.symptom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.rootCause.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.action.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCat && matchesSearch
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <p className="text-[10px] uppercase tracking-[0.3em] text-cyan-400 font-black">
            Universal Forensic Knowledge Base
          </p>
          <h2 className="text-2xl font-black text-white">Pathology & Symptom Matrix</h2>
        </div>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search symptoms, knock, smoke, EV..."
          className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm w-full md:w-72 focus:border-cyan-400 outline-none"
        />
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black uppercase whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/40'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setActiveItem(item)}
            className="cursor-pointer rounded-2xl border border-slate-800 bg-slate-900/80 p-5 hover:border-cyan-500/60 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] uppercase tracking-wider font-mono font-bold text-slate-400">
                  {item.category}
                </span>
                <span
                  className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                    item.severity === 'CRITICAL'
                      ? 'bg-red-950 text-red-400 border border-red-800'
                      : item.severity === 'HIGH'
                        ? 'bg-orange-950 text-orange-400 border border-orange-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}
                >
                  {item.severity}
                </span>
              </div>
              <h3 className="font-black text-white text-base leading-snug">{item.symptom}</h3>
              <p className="text-sm text-slate-300 mt-2">
                <span className="text-slate-500 font-bold">Probable Pathology:</span> {item.rootCause}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-xs font-mono text-cyan-400">{item.frequencyOrSpecs || 'Forensic Visual'}</span>
              <span className="text-xs font-bold text-slate-400 hover:text-cyan-300">View Protocol →</span>
            </div>
          </div>
        ))}
      </div>

      {activeItem && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs uppercase tracking-widest font-mono text-cyan-400">
                  {activeItem.category} PROTOCOL
                </span>
                <h3 className="text-xl font-black text-white mt-1">{activeItem.symptom}</h3>
              </div>
              <button
                onClick={() => setActiveItem(null)}
                className="text-slate-400 hover:text-white font-black text-lg p-1"
              >
                ✕
              </button>
            </div>

            <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 space-y-2">
              <p className="text-xs text-slate-400 font-bold uppercase">Root Cause Analysis</p>
              <p className="text-sm text-slate-200">{activeItem.rootCause}</p>
            </div>

            <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 space-y-2">
              <p className="text-xs text-slate-400 font-bold uppercase">Engineering Action Protocol</p>
              <p className="text-sm text-amber-200 font-medium">{activeItem.action}</p>
            </div>

            {activeItem.frequencyOrSpecs && (
              <div className="flex justify-between items-center text-xs px-2 text-slate-400 font-mono">
                <span>Frequency / Measurement Band:</span>
                <span className="text-cyan-300 font-bold">{activeItem.frequencyOrSpecs}</span>
              </div>
            )}

            <button
              onClick={() => setActiveItem(null)}
              className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs uppercase"
            >
              Close Protocol
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
