import { useEffect, useState, type ReactNode } from 'react'
import { aiService, type AIProvider } from '../services/aiService'
import { ollamaService } from '../services/ollamaService'

export type View = 'inspect' | 'guardian' | 'insights' | 'hub' | 'matrix' | 'testlab'

export function Layout({
  view,
  setView,
  children,
}: {
  view: View
  setView: (v: View) => void
  children: ReactNode
}) {
  const [provider, setProvider] = useState<AIProvider>(aiService.getActiveProvider())
  const [ollamaOnline, setOllamaOnline] = useState<boolean | null>(null)
  const [activeModel, setActiveModel] = useState<string>(ollamaService.getTextModel())

  useEffect(() => {
    const unsub = aiService.onProviderChange((p) => setProvider(p))
    const checkStatus = () => {
      ollamaService.checkHealth().then((h) => {
        setOllamaOnline(h.isOnline)
        setActiveModel(ollamaService.getTextModel())
      })
    }
    checkStatus()
    const interval = setInterval(checkStatus, 15000)
    return () => {
      unsub()
      clearInterval(interval)
    }
  }, [])

  const toggleProvider = () => {
    const next: AIProvider = provider === 'ollama' ? 'gemini' : 'ollama'
    aiService.setActiveProvider(next)
    setProvider(next)
  }

  const tabs: { id: View; label: string; icon: string }[] = [
    { id: 'inspect', label: 'Inspect', icon: '🎥' },
    { id: 'guardian', label: 'Guardian GPS', icon: '🛡️' },
    { id: 'insights', label: 'Fleet Analytics', icon: '📊' },
    { id: 'matrix', label: 'Pathology Matrix', icon: '🔬' },
    { id: 'hub', label: 'Intel Hub', icon: '📡' },
    { id: 'testlab', label: 'Test Lab', icon: '🧪' },
  ]

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-slate-950">
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 px-4 py-3">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView('inspect')}>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center font-black text-white text-base shadow-lg shadow-cyan-900/30">
                AG
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-lg font-black tracking-tight text-white">AutoGuard AI</h1>
                  <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/80">
                    GDVF v2.5
                  </span>
                </div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-slate-400 font-bold">
                  Vehicle Forensics & Tactical GPS
                </p>
              </div>
            </div>

            {/* AI Engine Switcher Badge (Mobile View) */}
            <div className="sm:hidden flex items-center">
              <button
                onClick={toggleProvider}
                title="Click to toggle AI Engine (Local Ollama vs Cloud Gemini)"
                className={`px-2.5 py-1 rounded-xl text-[10px] font-mono font-bold flex items-center gap-1.5 border transition-all ${
                  provider === 'ollama'
                    ? 'bg-emerald-950/60 border-emerald-700/80 text-emerald-300'
                    : 'bg-blue-950/60 border-blue-700/80 text-blue-300'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${ollamaOnline ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                {provider === 'ollama' ? 'Local Ollama' : 'Cloud Gemini'}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2.5 overflow-x-auto">
            {/* AI Engine Switcher Badge (Desktop View) */}
            <button
              onClick={toggleProvider}
              title="Click to toggle between Local Ollama and Cloud Gemini"
              className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-mono font-semibold transition-all hover:scale-105 active:scale-95 ${
                provider === 'ollama'
                  ? 'bg-emerald-950/60 border-emerald-600/60 text-emerald-300 hover:bg-emerald-900/40'
                  : 'bg-blue-950/60 border-blue-600/60 text-blue-300 hover:bg-blue-900/40'
              }`}
            >
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  provider === 'ollama'
                    ? ollamaOnline
                      ? 'bg-emerald-400 shadow-sm shadow-emerald-400 animate-pulse'
                      : 'bg-rose-500'
                    : 'bg-blue-400'
                }`}
              />
              <span className="flex flex-col text-left">
                <span className="text-[11px] font-black uppercase tracking-wider">
                  {provider === 'ollama' ? '🤖 Local AI (Ollama)' : '☁️ Cloud AI (Gemini)'}
                </span>
                <span className="text-[9px] text-slate-400">
                  {provider === 'ollama'
                    ? ollamaOnline
                      ? `${activeModel} · Online`
                      : 'Ollama Offline'
                    : 'Gemini 2.5 Pro'}
                </span>
              </span>
            </button>

            <nav className="flex gap-1 bg-slate-900/90 border border-slate-800 rounded-2xl p-1 overflow-x-auto">
              {tabs.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setView(t.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase whitespace-nowrap transition-all flex items-center gap-1.5 ${
                    view === t.id
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{t.icon}</span>
                  <span>{t.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-5xl w-full mx-auto p-4 md:p-6 flex-1">{children}</main>

      <footer className="border-t border-slate-900 py-4 text-center text-xs text-slate-600 font-mono">
        AutoGuard AI — Global Director of Vehicle Forensics & Reconditioning (GDVF) · Universal Vehicle Diagnostic Engine
      </footer>
    </div>
  )
}
