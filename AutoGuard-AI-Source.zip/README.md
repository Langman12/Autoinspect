# AutoGuard AI — Extracted Source

Vehicle forensic inspection + Global Guardian GPS co-pilot.

These files were reconstructed from your **AutoGuard_BugFix_Prompts** Google Doc
(the 20 code-fix prompts written for Google AI Studio). Old Grok chat history
cannot be read, so this is the complete AutoGuard source that exists from your Drive.

## Where to find this on Google Drive

Open this folder:

**AutoGuard AI - Source Code**
https://drive.google.com/drive/folders/16ODm1ZIXnfzzddSPWV9z_zLgaiL35H8q

Original prompt document (the 20 AI Studio bug-fix prompts):
https://docs.google.com/document/d/1FLrLKYUMu6fu4277ayHQwN7KaGtTwxahnJrS_HjnyyQ/edit

Empty companion folder (created earlier, unused):
**AutoGuard AI Inspections**
https://drive.google.com/drive/folders/1nLLbtCH8qRw4T7D7J5LcODhljI5WtY7n

## Folder layout

```
src/
  App.tsx
  main.tsx
  types.ts
  components/
    CameraView.tsx
    GuardianView.tsx
    ReportView.tsx
    FleetInsights.tsx
    VehicleTimeline.tsx
    Layout.tsx
    ErrorBoundary.tsx
    IntelligenceHub.tsx
    DiagnosticMatrix.tsx
    AcousticVisualizer.tsx
  services/
    aiService.ts
    ollamaService.ts
    geminiService.ts
    storageService.ts
    weatherService.ts
    recallService.ts
    firebaseService.ts
docs/
  AutoGuard_BugFix_Prompts.txt
  AutoGuard_Session_Prompts_And_Chat_History_2026-09-04.md
  global-guardian-gps.txt
  reports-body-mechanical.txt
  universal-vehicle-types.txt
scripts/
  generate_docx_report.py
  test-all-unit.mjs
  test-weather-unit.mjs
  test-recall-unit.mjs
  test-ollama.js
  test-weather.js
.project-intel/
  project-state.json
  changelog.md
  docs/
```

## What this app does

- **Vehicle Forensic Inspection (GDVF):** 6-phase visual, undercarriage, and acoustic engine analysis.
- **Acoustic FFT Visualizer:** 20Hz–20kHz spectrum analyzer with 20Hz Biquad highpass filter for mechanical knock/tick detection.
- **Live Tactical Guardian GPS:** Real-time road grip HUD (15%–99%) and safe speed caps powered by Open-Meteo.
- **Hybrid AI Engine:** 100% offline via local Ollama (`moondream`, `llama3.2:3b`, `qwen2.5`) with seamless Gemini Cloud failover.
- **IndexedDB Persistence:** Unlimited offline storage for high-res photo audits without localStorage quota limits.
- **NHTSA Recall Audits & Sanitized PDF/JSON Export:** Government safety recalls and dual-mode reporting.

## Setup & Running

1. Copy `.env.example` to `.env` (configure Ollama or Gemini API key)
2. `npm install`
3. `npm run dev`

## Automated Tests & Verification

```bash
# Run the complete 15-suite automated test harness (unit, integration, e2e)
node --experimental-strip-types scripts/run-all-tests.mjs

# Run TypeScript compilation check
./node_modules/.bin/tsc --noEmit

# Build production bundle
./node_modules/.bin/vite build
```

## Core Production Capabilities

- **Vehicle Forensic Inspection (GDVF):** 6-phase visual, undercarriage, ADAS, and acoustic engine analysis.
- **Acoustic Diagnostic Intelligence & Research Knowledge Base:**
  - Standardized mechanical fault registry (`FAULT-ENG-001` rod knock, piston slap, lifter tick, belt slip, wheel bearing wear, alternator whine, turbo surge, brake glaze).
  - Advanced DSP feature extraction: Spectral Centroid, Wiener Spectral Flatness, Spectral Bandwidth, Zero-Crossing Rate, Spectral Entropy, Harmonic-to-Noise Ratio (HNR in dB), and 13-band Mel Filterbanks.
  - In-browser Machine Learning training pipeline with Gaussian feature-space classifier, 300+ sample synthetic auto-seeder, confusion matrix heatmap, and ROC-AUC evaluation.
- **Acoustic FFT Visualizer:** 20Hz–20kHz real-time spectrum analyzer with 20Hz Biquad highpass filter and live DSP Research Telemetry HUD.
- **Live Tactical Guardian GPS:** Real-time road grip HUD (15%–99%) and safe speed caps powered by Open-Meteo.
- **Hybrid AI Engine:** 100% offline via local Ollama (`moondream`, `llama3.2:3b`, `qwen2.5`) with seamless Gemini Cloud failover.
- **IndexedDB Persistence:** Unlimited offline storage for high-res photo audits without localStorage quota limits.
- **NHTSA Recall Audits & Sanitized PDF/JSON Export:** Government safety recalls and dual-mode reporting.

